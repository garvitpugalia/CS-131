interface State {
    int size();
    byte[] current();
    boolean swap(int i, int j);
}
